package personnel;
import java.util.ArrayList;

public class Personnel {

	// the ArrayList should be parameterized here. This warning
	// should go away
	public static ArrayList readPersonnel(String filename) {
		return null;
	}
	
	public static void main(String[] args) {
		
	}
}
